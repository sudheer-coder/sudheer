import { Component, OnInit } from '@angular/core';
import { Itemservice } from '../Items.service';
import { Itemlist } from '../Itemsearch';

@Component({
  selector: 'app-additems',
  templateUrl: './additems.component.html',
  styleUrls: ['./additems.component.css']
})
export class AdditemsComponent implements OnInit {
  sellerId:any;
  itemId:any;
  productName:any;
  manufacturer:any;
  model:any;
  price:any;
  quantity:any;
  description:any;
  picture:any;
  imgURL: any;
  selectedFile: File;
  items:Itemlist = new Itemlist();
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  } 
  public onFileChanged(event) {
    //Select File
    console.log("in onfilechange method)");
    this.selectedFile = event.target.files[0];
  }

  additems() 
  { 
    console.log(this.selectedFile);
    const uploadProductData = new FormData();
    console.log("in add item method");
    uploadProductData.append('imageFile', this.selectedFile, this.selectedFile.name);
    uploadProductData.append('productName', this.productName);
    uploadProductData.append('manufacturer', this.manufacturer);
    uploadProductData.append('model', this.model);
    uploadProductData.append('price', this.price);
    uploadProductData.append('quantity', this.quantity);
    uploadProductData.append('description',this.description);
    this.sellerId=window.localStorage.getItem('sellerid');

    this.dataService.additems(uploadProductData,this.sellerId).subscribe(Itemlist=>this.items=Itemlist);
  } 
 
}
