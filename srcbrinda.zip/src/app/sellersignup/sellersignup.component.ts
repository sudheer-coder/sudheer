import { Component, OnInit } from '@angular/core';
import { seller } from '../seller';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {
  
  username:String;
  password:String;
  gstIn:String;
  briefAboutCompany:String;
  postalAddress:String;
  website:String;
  emialID:String;
  contactNumber:number;
  constructor(private dataService: Itemservice){}
  sellerdetails:seller;

  addseller()
  { 
    this.sellerdetails = new seller();
    this.sellerdetails.username=this.username;
    this.sellerdetails.password=this.password;
    this.sellerdetails.gstIn=this.gstIn;
    this.sellerdetails.briefAboutCompany=this.briefAboutCompany;
    this.sellerdetails.postalAddress=this.postalAddress;
    this.sellerdetails.website=this.website;
    this.sellerdetails.emialID=this.emialID;
    this.sellerdetails.contactNumber=this.contactNumber;
    console.log("in sellerts" + this.sellerdetails);
    this.dataService.addseller(this.sellerdetails).subscribe(seller=>this.sellerdetails=seller);

  }
  
  ngOnInit(): void {
  }

}
