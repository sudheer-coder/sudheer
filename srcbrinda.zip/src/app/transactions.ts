export class transactions
{
    transactionType:String;
    dateTime:Date;
    remarks:String;
    price:number
}
