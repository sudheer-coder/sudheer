export class buyer
{
    password:String;
    emailId:String;
    mobileNumber:number
}
