export class itemsmodel
{
    
    name: String;
    Addresss:String;
    city: String;
    package:String;
    trainerreference: String;
    phone: number;
}