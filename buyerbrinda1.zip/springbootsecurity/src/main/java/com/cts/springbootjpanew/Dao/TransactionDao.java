package com.cts.springbootjpanew.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.springbootjpanew.entity.TransactionHistory;

public interface TransactionDao extends JpaRepository<TransactionHistory, Integer>{

}
