package com.cts.springbootjpanew.entity;

public class AuthToken {

    private String token;
    private String username;
    private int buyerid;

    public AuthToken(){

    }

	public AuthToken(String token, String username, int buyerid) {
		super();
		this.token = token;
		this.username = username;
		this.buyerid = buyerid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

   
}
