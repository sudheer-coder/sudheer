package com.cts.springbootjpanew.controller;

import javax.security.sasl.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import com.cts.springbootjpanew.config.JwtTokenUtil;
import com.cts.springbootjpanew.entity.ApiResponse;
import com.cts.springbootjpanew.entity.AuthToken;
import com.cts.springbootjpanew.entity.BuyerDetails;
import com.cts.springbootjpanew.entity.LoginUser;
import com.cts.springbootjpanew.service.Iservice;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/token")
public class AuthenticationController {

    @Autowired(required=true)
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private Iservice buyerservice;

    @RequestMapping(value = "/generate-token", method = RequestMethod.POST)
    
    public ApiResponse<AuthToken> register(@RequestBody LoginUser loginUser) throws AuthenticationException {
    	System.out.println(loginUser.getUsername());
    	authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        final BuyerDetails buyerdetails = buyerservice.findOne(loginUser.getUsername());
        
        final String token = jwtTokenUtil.generateToken(buyerdetails);
        System.out.println(token);
        return new ApiResponse<>(200, "success",new AuthToken(token, buyerdetails.getBuyerName(),buyerdetails.getBuyerID()));
    }

}
