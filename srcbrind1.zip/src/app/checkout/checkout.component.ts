import { Component, OnInit, ɵConsole } from '@angular/core';
import { transactions } from '../transactions';
import { Itemservice } from '../Items.service';
import { cartitems } from '../cartitem';
import { Itemlist } from '../Itemsearch';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  cartitemses:cartitems[];
  transaction:transactions;
  transaction1:transactions;
  transactionType:String;
  price:number;
  remarks:String;
  items:Itemlist = new Itemlist();
  items1:Itemlist = new Itemlist();
  quantity:number;
  itemid:number;
  buyerId:number;
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  }
  
 checkout()
  {
    this.buyerId=+window.localStorage.getItem('buyerid');
    this.transaction = new transactions();
    this.transaction.remarks=this.remarks;
    this.dataService.getAllitems().subscribe(cartitems=>{this.cartitemses=cartitems;
      for (var product of this.cartitemses) {
        this.items.quantity=product.quantity;
        this.itemid=product.itemId;
        console.log(this.itemid);
        console.log(product.quantity);
        this.dataService.getItemById(this.itemid).subscribe(Itemlist=>{this.items1=Itemlist;
        console.log(this.items1.quantity); 
        this.items.quantity=this.items1.quantity-product.quantity;
        console.log(this.items);
        });
        this.dataService.updatequantity(this.items,this.itemid).subscribe(Itemlist=>this.items=Itemlist);
        
   }
  });
  this.transaction.transactionType=this.transactionType;
    this.dataService.checckout(this.transaction,this.buyerId).subscribe(transactions=>{this.transaction1=transactions;
      console.log(this.transaction1);
      alert(this.transaction1);
    });
    
  
  }
  

}
