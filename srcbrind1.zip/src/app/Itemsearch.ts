export class Itemlist
{   
    itemId:number;
    productName:String;
    manufacturer:String;
    model:String;
    price:any;
    quantity:number;
    description:String;
    picture:String;
    }