import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { GetallcartitemsComponent } from './getallcartitems/getallcartitems.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { NavigationbarComponent } from './navigationbar/navigationbar.component';
import { LoginformComponent } from './loginform/loginform.component';
import { LogoutComponent } from './logout/logout.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';



const routes: Routes = [
  {path:'navigation/buyersignup',component: UsersignupComponent},
  {path:'navigation/cartitems',component: GetallcartitemsComponent},
  {path:'checkout',component: CheckoutComponent},
  {path:'navigation',component: NavigationbarComponent},
  {path:'Login',component: LoginformComponent},
  {path:'navigation/logout',component: LogoutComponent},
  {path:'purchase',component: PurchasehistoryComponent}
  
  

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }