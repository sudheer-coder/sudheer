import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { cartitems } from './cartitem';
import { ApiResponse } from './api.response';

@Injectable({
    providedIn: 'root'
  })
  export class Itemservice 
  { 
    private baseUrl = 'http://localhost:8989/mentorportal/sellerService/seller/seller/search';
    private baseUrl1 = 'http://localhost:8989/mentorportal/buyerService/buyer/Add/items';
    private baseurl5 = 'http://localhost:8989/mentorportal/buyerService/buyer/getAll/items';
    private baseurl6 = 'http://localhost:8989/mentorportal/buyerService/buyer/checkout';
    private baseurl7 = 'http://localhost:8989/mentorportal/buyerService/buyer/Add/buyer';
    private baseurl9 = 'http://localhost:8989/mentorportal/buyerService/buyer/update/items';
    private baseurl10 = 'http://localhost:8989/mentorportal/buyerService/buyer/DeleteItem';
    private baseurl11 = 'http://localhost:8989/mentorportal/buyerService/token/generate-token';
    private baseurl12 ='http://localhost:8989/mentorportal/sellerService/seller/updateqnty';
    private baseurl13 ='http://localhost:8989/mentorportal/sellerService/seller/getitembyid';
    private baseurl14 ='http://localhost:8989/mentorportal/buyerService/buyer/getpurchase';

    
    
    constructor(private http: HttpClient) { }
    //seller
    login(loginpayload:object):Observable<ApiResponse>
    {  
      console.log("in login service method");
      console.log(loginpayload);
       return this.http.post<ApiResponse>(`${this.baseurl11}`,loginpayload);
    }
    getItemByName(Itemsearch1:Object):Observable<any>
    {   
        console.log("in sevie method");
        console.log(Itemsearch1);
        console.log(this.baseUrl)
        return this.http.post(`${this.baseUrl}`,Itemsearch1);
    }
    getItemById(itemId:number):Observable<any>
    {
      return this.http.get(`${this.baseurl13}/${itemId}`);
    }
    updatequantity(Itemlist:object,itemid:number):Observable<any>
    {
      console.log("in service of quantityy");
      return this.http.put(`${this.baseurl12}/${itemid}`,Itemlist)
    } 

    //buyer
    addbuyer(buyer:object):Observable<any>
    { 
      
  console.log("in last ts");
  console.log(buyer);
      return this.http.post(`${this.baseurl7}`,buyer);
    }
    addcartitem(cartitems:object,buyerId:number):Observable<any>
    {
      console.log(cartitems);
      console.log(this.baseUrl1);
      return this.http.post(`${this.baseUrl1}/${buyerId}`,cartitems);
    }
    updatecartitem(cartitem:cartitems,cartitemid:number):Observable<any>
    { 
      
    console.log("in update ts");
    console.log(cartitemid);
    console.log(cartitem);
      return this.http.put(`${this.baseurl9}/${cartitemid}`,cartitem)
    }
    getAllitems():Observable<any>
    { 
      console.log("enter into feall service");
      return this.http.get(`${this.baseurl5}`);
    }
    deletecartitem(cartitemid:number,buyerid:number):Observable<any>
    {
      console.log("enter into delete service");
      return this.http.delete(`${this.baseurl10}/${cartitemid}/${buyerid}`);
    }
    checckout(transactions:object,buyerid:number):Observable<any>
    {
      return this.http.post(`${this.baseurl6}/${buyerid}`,transactions);
    }
    purchase(buyerid:number):Observable<any>
    {
      return this.http.get(`${this.baseurl14}/${buyerid}`);
    }
  }