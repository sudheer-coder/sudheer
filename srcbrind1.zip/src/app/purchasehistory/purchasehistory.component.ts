import { Component, OnInit } from '@angular/core';
import { Itemservice } from '../Items.service';
import { Purchase } from '../purchase';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchasehistoryComponent implements OnInit {
  buyerId:number;
  purchasehistory:Purchase;
  constructor(private dataService: Itemservice) { }

  ngOnInit(): void {
    this.buyerId =23;//+window.localStorage.getItem('buyerid');
    this.dataService.purchase(this.buyerId).subscribe(Purchase=>this.purchasehistory=Purchase);
  }

}
