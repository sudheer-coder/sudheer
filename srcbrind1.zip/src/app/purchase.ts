export class Purchase
{
    purchaseHistoryId:number;
    itemId:number;
    numberOfItems:number;
    remarks:String;

}