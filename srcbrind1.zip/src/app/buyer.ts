export class buyer
{
    buyerName:String;
    password:String;
    emailId:String;
    mobileNumber:number
}
