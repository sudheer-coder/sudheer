import { Component, OnInit } from '@angular/core';
import { buyer } from '../buyer';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
  emailId:String;
  password:String;
  mobileNumber:number;
  buyerName:String;
  constructor(private dataService: Itemservice){}
  buyerdetails:buyer;
  addbuyer()
  {
  this.buyerdetails = new buyer();
  this.buyerdetails.buyerName=this.buyerName;
  this.buyerdetails.emailId=this.emailId;
  this.buyerdetails.password=this.password;
  this.buyerdetails.mobileNumber=this.mobileNumber;
  console.log("in service ts");
  console.log(this.buyerdetails);
  this.dataService.addbuyer(this.buyerdetails).subscribe(buyers=>this.buyerdetails=buyers)
}
  ngOnInit(): void {
  }

}
