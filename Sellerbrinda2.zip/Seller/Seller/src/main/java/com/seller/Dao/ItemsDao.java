package com.seller.Dao;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.seller.entity.Items;
@Repository

public interface ItemsDao extends JpaRepository<Items, Integer>{
	@Modifying
	@Transactional
	@Query(value="delete from Items where itemId=?1 and SellerId=?2",nativeQuery = true)
	public void deleteItem(int iid,int sid);
	@Query(value="from Items where productName like %:itemName%")
	public List<Items> finditem(@Param("itemName") String itemName);

}
