package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SellerDetails implements Serializable{
	@GeneratedValue
	@Id
	private int sellerId;
	private String username;
	private String password;
	private String gstIn;
	private String briefAboutCompany;
	private String postalAddress;
	private String website;
	private String emialID;
	private long contactNumber;
	public SellerDetails() 
	{
		
	}
	public SellerDetails(int sellerId, String username, String password, String gstIn, String briefAboutCompany,
			String postalAddress, String website, String emialID, long contactNumber) {
		super();
		this.sellerId = sellerId;
		this.username = username;
		this.password = password;
		this.gstIn = gstIn;
		this.briefAboutCompany = briefAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emialID = emialID;
		this.contactNumber = contactNumber;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getGstIn() {
		return gstIn;
	}
	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}
	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}
	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}
	public String getPostalAddress() {
		return postalAddress;
	}
	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmialID() {
		return emialID;
	}
	public void setEmialID(String emialID) {
		this.emialID = emialID;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "SellerDetails [sellerId=" + sellerId + ", username=" + username + ", password=" + password + ", gstIn="
				+ gstIn + ", briefAboutCompany=" + briefAboutCompany + ", postalAddress=" + postalAddress + ", website="
				+ website + ", emialID=" + emialID + ", contactNumber=" + contactNumber + "]";
	}



}
